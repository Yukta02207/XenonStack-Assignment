# shopping-website
RUN npm install before running in your devices
This is a shopping website built using :
~HTML, CSS ,JavaScript for FRONTEND
~Nodejs, MongoDb for BACKEND
It serves two perspectives, first one that the user is an admin who can add products, modify them, remove them e.t.c 
and other perspective birng the customer who visits to shop. User can add products to the cart without logging in but needs to login before proceeding 
to buy.
