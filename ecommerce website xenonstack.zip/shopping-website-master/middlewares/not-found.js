function notfound(req,res){
    res.render('shared/404')
}

module.exports = notfound